<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\{UsuariosController,MenuController,RolesController};
use App\Http\Controllers\VehiculosController;
use App\Http\Controllers\TipoVehiculosController;
use App\Http\Controllers\ClientesController;
use App\Http\Controllers\ArriendosController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});


Route::post('/usuarios/login',[UsuariosController::class,'login'])->name('usuarios.login');
Route::get('/usuarios/logout',[UsuariosController::class,'logout'])->name('usuarios.logout');
Route::get('/menu',[MenuController::class,'index'])->name('menu.index');
Route::resource('/usuarios',UsuariosController::class);
Route::resource('/roles',RolesController::class);

Route::get('/vehiculos',[VehiculosController::class,'index'])->name('vehiculo.index');
Route::post('/vehiculos',[VehiculosController::class,'store'])->name('vehiculo.store');
Route::delete('/vehiculos/{vehiculo}',[VehiculosController::class,'destroy'])->name('vehiculo.destroy');
Route::get('/vehiculos/{vehiculo}/edit',[VehiculosController::class,'edit'])->name('vehiculo.edit');
Route::get('/vehiculos2/{vehiculo}/edit',[VehiculosController::class,'edit7'])->name('vehiculo2.edit');
// Route::get('/vehiculos/{vehiculo}/edit',[VehiculosController::class,'edit'])->name('vehiculo.edit');
Route::put('/vehiculos/{vehiculo}',[VehiculosController::class,'update'])->name('vehiculo.update');
// Route::get('/vehiculo2/{vehiculo}/edit',[VehiculosController::class,'edit3'])->name('vehiculo2.edit');
Route::put('/vehiculos2/{vehiculo}',[VehiculosController::class,'update2'])->name('vehiculo2.update');
Route::put('/vehiculos3/{vehiculo}',[VehiculosController::class,'update3'])->name('vehiculo3.update');

Route::get('/tipovehiculos',[TipoVehiculosController::class,'index'])->name('tipovehiculo.index');
Route::post('/tipovehiculos',[TipoVehiculosController::class,'store'])->name('tipovehiculo.store');
Route::delete('/tipovehiculos/{tipovehiculo}',[TipoVehiculosController::class,'destroy'])->name('tipovehiculo.destroy');
Route::get('/tipovehiculos/{tipovehiculo}/edit',[TipoVehiculosController::class,'edit'])->name('tipovehiculo.edit');
Route::put('/tipovehiculos/{tipovehiculo}',[TipoVehiculosController::class,'update'])->name('tipovehiculo.update');

Route::get('/clientes',[ClientesController::class,'index'])->name('cliente.index');
Route::post('/clientes',[ClientesController::class,'store'])->name('cliente.store');
Route::delete('/clientes/{cliente}',[CLientesController::class,'destroy'])->name('cliente.destroy');
Route::get('/clientes/{cliente}/edit',[CLientesController::class,'edit'])->name('cliente.edit');
Route::put('/clientes/{cliente}',[CLientesController::class,'update'])->name('cliente.update');
Route::get('/clientesarriendo/{cliente}/edit',[CLientesController::class,'edit2'])->name('clientearriendo.edit');
// Route::put('/clientes/{cliente}',[CLientesController::class,'update2'])->name('clientearriendo.update');

Route::get('/arriendos/{arriendo}/edit',[ArriendosController::class,'edit'])->name('arriendo.edit');
Route::post('/arriendo',[ArriendosController::class,'store'])->name('arriendo.store');
Route::get('/arriendos',[ArriendosController::class,'index'])->name('arriendo.index');
// Route::get('/arriendos2',[ArriendosController::class,'add'])->name('arriendo.add');
Route::put('/arriendos/{arriendo}',[ArriendosController::class,'update'])->name('arriendo.update');
Route::delete('/arriendos/{arriendo}',[ArriendosController::class,'destroy'])->name('arriendo.destroy');
// Route::get('/vehiculos/{vehiculo}/edit',[VehiculosController::class,'edit'])->name('vehiculo.edit');
