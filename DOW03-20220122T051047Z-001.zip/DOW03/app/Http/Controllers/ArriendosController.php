<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;
use App\Models\Vehiculo;
use App\Models\tipoVehiculo;
use App\Models\arriendo;

class ArriendosController extends Controller
{
    public function index(){
        $arriendos = arriendo::all();
        
        // dd('lets go');
        return view('principal.arriendosindex', compact('arriendos'));
    }
    // public function edit(Vehiculo $vehiculo){
    //     $vehiculo = Vehiculo::all();
    //     return view('principal.arriendosedit', compact('vehiculo'));
    // }
    // public function add(Vehiculo $vehiculo){
    //     $arriendos = arriendo::all();
        
    //     dd($vehiculo);
    //     return view('principal.arriendosadd', compact('arriendos','vehiculo'));
    // }

    public function store(Request $request){
        $arriendo = new arriendo();
        $arriendo->valor_arriendo = $request->user2;
        $arriendo->patente = $request->user;
        $arriendo->estado = $request->tipo;
        $arriendo->cliente_id = $request->cliente;
        $arriendo->fecha_inicio_arriendo = $request->fecha1;
        $arriendo->fecha_termino_arriendo = $request->fecha2;
        $arriendo->devolucion_vehiculo = $request->fecha3;
        
        $arriendo->save();
        return redirect()->route('arriendo.index');
        
    }
    public function destroy(arriendo $arriendo){
        $arriendo->delete();
        return redirect()->route('arriendo.index');
    }
    public function edit(arriendo $arriendo){
        // $vehiculo = Vehiculo::all();
        // dd($arriendo);
        return view('principal.arriendosedit', compact('arriendo'));
    }
    public function update(Vehiculo $vehiculo,Request $request){
        $arriendo->valor_arriendo = $request->user2;
        $arriendo->patente = $request->user;
        $arriendo->estado = $request->tipo;
        $arriendo->cliente_id = $request->cliente;
        $arriendo->fecha_inicio_arriendo = $request->fecha1;
        $arriendo->fecha_termino_arriendo = $request->fecha2;
        $arriendo->devolucion_vehiculo = $request->fecha3;
        
        $arriendo->save();

        return redirect()->route('arriendo.index');
    }
    
}
