<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tipoVehiculo;

class TipoVehiculosController extends Controller
{
    public function index(){
        $tipovehiculos = tipoVehiculo::all();
        // dd('lets go');
        return view('principal.tipovehiculo', compact('tipovehiculos'));
    }
    public function store(Request $request){
        $tipovehiculo = new tipoVehiculo();
        $tipovehiculo->nombre_tipo = $request->user2;
        $tipovehiculo->valor_de_arriendo = $request->user;
       
        $tipovehiculo->save();
        return redirect()->route('tipovehiculo.index');
        
    }
    public function destroy(tipoVehiculo $tipovehiculo){
        $tipovehiculo->delete();
        return redirect()->route('tipovehiculo.index');
    }
    public function edit(tipoVehiculo $tipovehiculo){
        // $vehiculo = Vehiculo::all();
        return view('principal.tipovehiculoedit', compact('tipovehiculo'));
    }
    public function update(tipoVehiculo $tipovehiculo,Request $request){
        $tipovehiculo->nombre_tipo = $request->user2;
        $tipovehiculo->valor_de_arriendo = $request->user;
        // $vehiculo->marca = $request->marca;
        // $vehiculo->modelo = $request->modelo;
        // $vehiculo->color = $request->color;
        
        $tipovehiculo->save();

        return redirect()->route('tipovehiculo.index');
    }
}
