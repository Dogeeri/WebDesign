<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;
use App\Models\Vehiculo;
use App\Models\tipoVehiculo;
use App\Models\arriendo;
class ClientesController extends Controller
{
    public function index(){
        $clientes = Cliente::all();
        $vehiculos = Vehiculo::all();
        $tipovehiculos = tipoVehiculo::all();
        // dd('lets go');
        return view('principal.clientes', compact('clientes', 'vehiculos','tipovehiculos'));
    }
    public function store(Request $request){
        $cliente = new Cliente();
        $cliente->nombre_cliente = $request->user2;
        $cliente->correo = $request->user;
        $cliente->edad = $request->tipo;
        
        $cliente->save();
        return redirect()->route('cliente.index');
        
    }
    public function destroy(cliente $cliente){
        $cliente->delete();
        return redirect()->route('cliente.index');
    }
    public function update(cliente $cliente,Request $request){
        $cliente->nombre_cliente = $request->user2;
        $cliente->correo = $request->user;
        $cliente->edad = $request->tipo;
        // $vehiculo->marca = $request->marca;
        // $vehiculo->modelo = $request->modelo;
        // $vehiculo->color = $request->color;
        
        $cliente->save();

        return redirect()->route('cliente.index');
    }
    public function edit(cliente $cliente){
        // dd($cliente);
        return view('principal.clientesedit', compact('cliente'));
    }
    public function edit2(cliente $cliente){
        $clientes = Cliente::all();
        $arriendos = arriendo::all();
        
        return view('principal.arriendos', compact('clientes','arriendos'));
    }
}
