<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vehiculo;
use App\Models\tipoVehiculo;
use App\Models\Cliente;

class VehiculosController extends Controller
{
    public function index(){
        $vehiculos = Vehiculo::all();
        $tipovehiculos = tipoVehiculo::all();
        // dd('lets go');
        return view('principal.vehiculo', compact('vehiculos','tipovehiculos'));
    }

    public function store(Request $request){
        $vehiculo = new Vehiculo();
        $vehiculo->patente = $request->user2;
        $vehiculo->dueño_vehiculo = $request->user;
        $vehiculo->marca = $request->marca;
        $vehiculo->modelo = $request->modelo;
        $vehiculo->tipo_vehiculos = $request->tipo;
        $vehiculo->estado_vehiculo = $request->estado;
        $vehiculo->color = $request->color;
        $vehiculo->save();
        return redirect()->route('vehiculo.index');
        
    }
    public function edit(Vehiculo $vehiculo){
        // $vehiculo = Vehiculo::all();
        // dd($vehiculo);
        return view('principal.vehiculoedit', compact('vehiculo'));
    }
    public function edit7(Vehiculo $vehiculo){
        //$vehiculo = Vehiculo::all();
        // dd($vehiculo);
        $clientes = Cliente::all();
        return view('principal.arriendosadd', compact('vehiculo','clientes'));
    }
    public function destroy(Vehiculo $vehiculo){
        $vehiculo->delete();
        return redirect()->route('vehiculo.index');
    }
    public function update(Vehiculo $vehiculo,Request $request){
        $vehiculo->patente = $request->user2;
        $vehiculo->dueño_vehiculo = $request->user;
        $vehiculo->tipo_vehiculos = $request->tipo;
        $vehiculo->marca = $request->marca;
        $vehiculo->modelo = $request->modelo;
        $vehiculo->estado_vehiculo = $request->estado;
        $vehiculo->color = $request->color;
        
        $vehiculo->save();

        return redirect()->route('vehiculo.index');
    }
    public function update2(Vehiculo $vehiculo,Request $request){
        // $vehiculo->patente = $request->user2;
        // $vehiculo->dueño_vehiculo = $request->user;
        // $vehiculo->tipo_vehiculos = $request->tipo;
        // $vehiculo->marca = $request->marca;
        // $vehiculo->modelo = $request->modelo;
        $vehiculo->estado_vehiculo = 'disponible';
        // $vehiculo->color = $request->color;
        
        $vehiculo->save();

        return redirect()->route('vehiculo.index');
    }
    public function update3(Vehiculo $vehiculo,Request $request){
        // $vehiculo->patente = $request->user2;
        // $vehiculo->dueño_vehiculo = $request->user;
        // $vehiculo->tipo_vehiculos = $request->tipo;
        // $vehiculo->marca = $request->marca;
        // $vehiculo->modelo = $request->modelo;
        $vehiculo->estado_vehiculo = 'arrendado';
        // $vehiculo->color = $request->color;
        
        $vehiculo->save();

        return redirect()->route('vehiculo.index');
    }
}
