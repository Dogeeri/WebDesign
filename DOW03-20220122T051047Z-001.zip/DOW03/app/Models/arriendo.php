<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class arriendo extends Model
{
    use HasFactory,SoftDeletes;
    protected $table = 'arriendos';

    public function vehiculo(){
        return $this->belongsTo('App\Models\vehiculo');
    }
    public function cliente(){
        return $this->belongsTo('App\Models\Cliente');
    }
}
