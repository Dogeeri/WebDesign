<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vehiculo extends Model
{
    use HasFactory,SoftDeletes ;
    protected $table = 'vehiculos';
    protected $primaryKey= 'patente';
    public $incrementing=false;

    public function tipo_vehiculo(){
        return $this->belongsTo('App\Models\tipoVehiculo');
    }
    public function arriendo(){
        return $this->hasMany('App\Models\arriendo');
    }
}
