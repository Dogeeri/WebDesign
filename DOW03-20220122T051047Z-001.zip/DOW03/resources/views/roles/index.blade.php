<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body class="" style="background-image: url('{{ asset ('imagenes/autitoslogin.jpg') }}');"></body>

<div class="row ml-4 mt-2">
        <div class="card">
            <div class="card-header">
                <h5>Agregar Rol</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="{{route('roles.store')}}">
                    @csrf
                    <div class="form-group">
                        <label for="id">ID:</label>
                        <input type="text" id="id" name="id" class="form-control @error('id') is-invalid @enderror" value="{{old('id')}}">
                    </div>
                    <div class="form-group">
                        <label for="nombre">Nombre de Rol:</label>
                        <input type="text" id="nombre" name="nombre" class="form-control @error('nombre') is-invalid @enderror" value="{{old('nombre')}}">
                    </div>
                   
                    <div class="form-group">
                        <div class="row">
                            <div class="col-12 my-2">
                                <button type="reset" class="btn btn-danger btn-block">Cancelar</button>
                            </div>
                            <div class="col-12 my-2">
                                <a href="{{route('menu.index')}}" class="btn btn-warning text-white">Volver</a>
                            </div>
                            <div class="col-12 my-2">
                                <button type="submit" class="btn btn-info btn-block">Aceptar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-8 col-lg-8 mt-1 mt-lg-0">
                    <table class="table  text-dark table-bordered table-striped table-hover table-info">
                        <thead>
                            <tr>
                                <th class="d-none d-lg-table-cell">ID</th>
                                <th class="d-none d-lg-table-cell">Nombre</th>
                                </tr>
                        </thead>
                            @foreach ($roles as $num=>$rol)
                            <tr>
                                <td>{{$rol->id}}</td>
                                <td>{{$rol->nombre}}</td>
                            @endforeach
                    </table>
        </div>
























    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>