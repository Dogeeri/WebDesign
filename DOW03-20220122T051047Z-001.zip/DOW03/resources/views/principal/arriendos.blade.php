@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                @foreach ($arriendos as $arriendo)
                @foreach ($clientes as $cliente)
                @if($cliente->id==$arriendo->cliente_id)
                
                <div class="col-12 col-md-3">
                    <div class=" card " id= "rar" style="background-color: rgba(0, 0, 0, 0.781);">
                        <h4 class="text-white text-center">Arriendo de vehiculos</h4>
                        {{-- <img src="{{asset('imagenes/books37.jpg')}}" width="200" height="250" title="El codigo davinci" alt="Aquí esta la portada de el codigo davinci" class="card-img-top"/> --}}
                        <div class="card-body">
                            <div class="card-title">
                                {{-- <h4 class="text-white">{{$cliente->nombre_cliente}}</h4> --}}
                                <ul class="list-group list-group-flush text-white">
                                    
                                    
                                    
                                    
                                     <p>Nombre del cliente: {{$cliente->nombre_cliente}}</p>
                                    <p>correo del cliente: {{$cliente->correo}}</p>
                                    <p>edad del cliente: {{$cliente->edad}}</p> <p>valor_arriendo:   {{$arriendo->valor_arriendo}}</p>
                                    <p>patente:   {{$arriendo->patente}}</p> <p>cliente_id:   {{$arriendo->cliente_id}}</p> 
                                    
                                   
                                    
                                </ul>
                            </div>
                           
                        </div>
                        
                    </div>


                </div>
                @endif
                @endforeach
                @endforeach
                
            </div>
        </div>
</body>

        
@endsection


        