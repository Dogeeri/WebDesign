@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/DOW02CSS.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen4.jpg')}});">
        <div>
            <div class="flex-container ">
            
                
                    <div class=" col-12 col-md-3   card bg-ligth" id="rar" style="background-color: rgba(0, 0, 0, 0.781);" >
                        <div class=" card-title">
                            <h4 class="text-white text-center">Géneros</h4>
                        </div>
                        <div>
                            
                            <div class="collapse" id=rar10>
                                <div class="card-body">
                                    
                                    
                        </div>
                        
                    </div>
                    <!-- <h4>Generos</h4> -->
                    <div class="collapse" id=rar2>
                        <div class="card-body">
                            <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                            <img src="{{asset('imagenes/books11.jpg')}}" width="150" height="150"  class="card-img-top"/>
                            <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            
                        </div>

                    </div>
                    <a href="#rar2" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Ciencia Ficción</a>
                                    {{-- <!-- <div class="collapse" id=rar2>
                                        <div class="card-body">
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                            <img src="{{asset('imagenes/books11.jpg')}}" width="150" height="150" title="El alquimista" alt="aquí esta la portada del alquimista" class="card-img-top"/>
                                            
                                        </div>

                                    </div> --> --}}
                    <a href="#rar3" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Ciencias y naturaleza</a>
                    <div class="collapse" id=rar3>
                        <div class="card-body">
                            <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                            <img src="{{asset('imagenes/books32.jpg')}}" width="150" height="150"  class="card-img-top"/>
                            <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                        </div>
                    </div>
                    <a href="#rar4" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Medicina</a>
                        <div class="collapse" id=rar4>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books31.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    <a href="#rar5" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Arte y arquitectura</a>
                        <div class="collapse" id=rar5>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books29.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    <a href="#rar6" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Economía</a>
                        <div class="collapse" id=rar6>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books28.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    <a href="#rar7" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Tecnología</a>
                        <div class="collapse" id=rar7>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books12.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    <a href="#rar8" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Religion</a>
                        <div class="collapse" id=rar8>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books30.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    <a href="#rar9" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Filosofia</a>
                        <div class="collapse" id=rar9>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books27.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar11" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Historia</a>
                        <div class="collapse" id=rar11>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books25.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>

                        <a href="#rar12" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Ciencias Sociales</a>
                        <div class="collapse" id=rar12>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books26.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar13" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Deportes</a>
                        <div class="collapse" id=rar13>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books24.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar14" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Ciencias de la computación</a>
                        <div class="collapse" id=rar14>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books22.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar15" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Textos de estudio</a>
                        <div class="collapse" id=rar15>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books12.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar16" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Diccionarios</a>
                        <div class="collapse" id=rar16>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books21.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar17" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Turismo y viajes</a>
                        <div class="collapse" id=rar17>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books23.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                        <a href="#rar18" class=" btn  btn-outline-primary btn-xs" type="button" data-toggle="collapse">Ingeniería</a>
                        <div class="collapse" id=rar18>
                            <div class="card-body">
                                <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit tempora eveniet pariatur! Porro corrupti omnis aspernatur, deleniti suscipit magni eos facere molestias dolore nemo. Neque corporis odit quibusdam voluptas illo.</p> 
                                <img src="{{asset('imagenes/books20.jpg')}}" width="150" height="150"  class="card-img-top"/>
                                <a href="/catalogo" class="btn btn-success btn-lg active" role="button ">entrar</a>
                            </div>
                        </div>
                    
                    
                    
                    
                
                    
                    

                </div>
                

                
                

                <!-- <div class="col-3">
                    <h1>veamos</h1>
                </div> -->
            </div>
            <div class="col-12 col-md-3 card " id= "rar" style="background-color: rgba(0, 0, 0, 0.781);">
                <h4 class="text-white text-center">Libros del mes</h4>
                <img src="{{asset('imagenes/books2.jpg')}}" width="200" height="250" title="El alquimista" alt="aquí esta la portada del alquimista" class="card-img-top"/>
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="text-white">El alquimista</h4>
                    </div>
                    <p class="text-white" >Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis ea vitae distinctio temporibus. Quasi praesentium quae officiis nam recusandae sed numquam culpa?aesentium dicta?</p>

                </div>
                <div class=" row">
                    <div class="flex-container">
                        <div class="col-6">
                            <p class="text-white">$7.990         </p>
                        </div>
                        <div class="col-6">
                            <a href="/catalogo" class="btn btn-success btn-lg active" title="comprar" role="button ">
                                
                                <i class="fas fa-shopping-cart"></i>
                            </a>

                        </div>

                        
                        

                    </div>
                    

                </div>

            </div>
            <div class="col-12 col-md-6 card " id="ror" style="background-color: rgba(0, 0, 0, 0.781);" >
                <div class="card-title">
                    <h4 class="text-white text-center">Best sellers/exitos de venta</h4>
                </div>
                <div class="card-body">
                    <br>
                    <div class="container">
                        <div class="media">
                            <img src="{{asset('imagenes/books3.jpg')}}" width="150" height="150" />
                            <div class="media-body">
                                <p class="text-justify text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo, quidem doloremque! Doloribus asperiores placeat voluptate quaerat molestias accusamus dolore, nesciunt iure optio incidunt. Molestias officiis molestiae quibusdam ullam maiores! Cumque!</p>
                                <div class="flex-container">
                                    <div class="col-6">
                                    <p class="text-white">$16.990         </p>
                                    </div>
                                    <div class="col-6">
                                        <a href="/catalogo" class="btn btn-success btn-lg active" title="comprar" role="button ">
                                
                                            <i class="fas fa-shopping-cart"></i>
                                        </a>
                                    </div>
        
                                    
                                
        
                                </div>
                            </div>
                        </div>
                        
                    </div>

                </div>

                <div class="card-body">
                    
                    <div class="container">
                        <div class="media">
                            <img src="{{asset('imagenes/books14.jpg')}}" width="150" height="150" />
                            <div class="media-body">
                                <p class="text-justify text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo, quidem doloremque! Doloribus asperiores placeat voluptate quaerat molestias accusamus dolore, nesciunt iure optio incidunt. Molestias officiis molestiae quibusdam ullam maiores! Cumque!</p>
                                <div class="flex-container">
                                    <div class="col-6">
                                    <p class="text-white">$14.990         </p>
                                    </div>
                                    <div class="col-6">
                                        <a href="/catalogo" class="btn btn-success btn-lg active" title="comprar" role="button ">
                                
                                            <i class="fas fa-shopping-cart"></i>
                                        </a>
                                    </div>
        
                                    
                                
        
                                </div>
                            </div>
                        </div>
                        
                    </div>

                </div>
                
            </div>
                
        </div>
@endsection


        