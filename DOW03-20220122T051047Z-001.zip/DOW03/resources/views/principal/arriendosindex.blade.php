@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar arriendo</h3>
                            <form action="{{route('arriendo.store')}}" method="post">
                            
                                @csrf
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">valor arriendo</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique el valor del arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">patente</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique la patente.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">estado</label>
                                    <input type="text" id="tipo" name='tipo' class="form-control">
                                    <small class="form-text text-muted">Indique el estado.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">cliente id</label>
                                    <input type="text" id="cliente" name='cliente' class="form-control">
                                    <small class="form-text text-muted">Indique el cliente id.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha inicio arriendo</label>
                                    <input type="date" id="fecha1" name="fecha1" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de inicion delm arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha termino arriendo</label>
                                    <input type="date" id="fecha2" name="fecha2" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de termino del arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha devolucion vehiculo</label>
                                    <input type="date" id="fecha3" name="fecha3" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de devolucion del vehiculo.</small>
                                </div>
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="marca" name='marca' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="modelo" name='modelo' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Editorial</label>
                                    <select name="estado" id="estado" class="form-control">
                                        
                                        <option value="disponible">disponible</option>
                                        <option value="arrendado">arrendado</option>
                                        <option value="mantenimiento">mantenimiento</option>
                                        <option value="de baja">de baja</option>
                                        
                                    </select>
                                    
                                </div> --}}
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="color" name='color' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div> --}}
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Editorial</label>
                                    <select name="editorial" id="editorial" class="form-control">
                                        
                                        <option value="disponible">disponible</option>
                                        <option value="arrendado">arrendado</option>
                                        <option value="mantenimiento">mantenimiento</option>
                                        <option value="de baja">de baja</option>
                                        
                                    </select>
                                    
                                </div> --}}
                                
                                

                                

                            
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>valor arriendo
                                </a></th> 
                                <th>patente
                                </a></th>
                                <th>estado</th>
                                <th>id cliente </th>
                                <th>fecha inicio </th>
                                
                                
                                <th>fecha termino
                                </a></th>
                                <th>fecha devolucion</th>                       
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            @foreach ($arriendos as $arriendo)
                            <tr>
                                <td>
                                    
                                    {{-- <form method="POST" action="{{route('cliente.destroy', $cliente->id)}}" >
                                        {{$cliente->id}}
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="{{route('cliente.edit', $cliente)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form> --}}
                                    {{$arriendo->id}}
                                    <form method="POST" action="{{route('arriendo.destroy', $arriendo->id)}}" >
                                        {{-- {{$cliente->id}} --}}
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="{{route('arriendo.edit', $arriendo)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                {{-- <td>
                                    {{$cliente->id}}
                                </td> --}}
                                {{-- @foreach ($tipovehiculos as $tipovehiculo)
                            
                                    @if($tipovehiculo->id==$vehiculo->tipo_vehiculos) <td>{{$tipovehiculo->nombre_tipo}} <a href="/autores" class="btn btn-success btn-lg active " title="autores" role="button ">
                                        
                                        <i class="far fa-book"></i> </td>  @endif
                            
                                 @endforeach --}}
                                <td>
                                    {{$arriendo->valor_arriendo}}
                                </td>
                                <td>
                                    {{$arriendo->patente}}
                                </td>
                                <td>
                                    {{$arriendo->estado}}
                                    {{-- <a href="{{route('clientearriendo.edit', $cliente)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                        <i class="far fa-user-edit"></i> --}}
                                </td>
                                <td>
                                    {{$arriendo->cliente_id}}
                                </td>
                                <td>
                                    {{$arriendo->fecha_inicio_arriendo}}
                                </td>
                                <td>
                                    {{$arriendo->fecha_termino_arriendo}}
                                </td>
                                <td>
                                    {{$arriendo->devolucion_vehiculo}}
                                </td>
                                
                                
                                
                                
                            </tr>
                            @endforeach
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
@endsection


        