@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar cliente</h3>
                            <form action="{{route('cliente.store')}}" method="post">
                            
                                @csrf
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Nombre del cliente</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique el nombre del cliente.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">correo</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique el correo del cliente.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">edad</label>
                                    <input type="text" id="tipo" name='tipo' class="form-control">
                                    <small class="form-text text-muted">Indique la edad.</small>
                                </div>
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="marca" name='marca' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="modelo" name='modelo' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Editorial</label>
                                    <select name="estado" id="estado" class="form-control">
                                        
                                        <option value="disponible">disponible</option>
                                        <option value="arrendado">arrendado</option>
                                        <option value="mantenimiento">mantenimiento</option>
                                        <option value="de baja">de baja</option>
                                        
                                    </select>
                                    
                                </div> --}}
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="color" name='color' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div> --}}
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Editorial</label>
                                    <select name="editorial" id="editorial" class="form-control">
                                        
                                        <option value="disponible">disponible</option>
                                        <option value="arrendado">arrendado</option>
                                        <option value="mantenimiento">mantenimiento</option>
                                        <option value="de baja">de baja</option>
                                        
                                    </select>
                                    
                                </div> --}}
                                
                                

                                

                            
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre_cliente
                                </a></th> 
                                <th>correo
                                </a></th>
                                <th>edad</th>
                                <th>modelo </th>
                                <th>estado del vehiculo </th>
                                
                                
                                <th>color
                                </a></th></th>
                                
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            @foreach ($clientes as $cliente)
                            <tr>
                                <td>
                                    
                                    <form method="POST" action="{{route('cliente.destroy', $cliente->id)}}" >
                                        {{$cliente->id}}
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="{{route('cliente.edit', $cliente)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                {{-- <td>
                                    {{$cliente->id}}
                                </td> --}}
                                {{-- @foreach ($tipovehiculos as $tipovehiculo)
                            
                                    @if($tipovehiculo->id==$vehiculo->tipo_vehiculos) <td>{{$tipovehiculo->nombre_tipo}} <a href="/autores" class="btn btn-success btn-lg active " title="autores" role="button ">
                                        
                                        <i class="far fa-book"></i> </td>  @endif
                            
                                 @endforeach --}}
                                <td>
                                    {{$cliente->nombre_cliente}}
                                </td>
                                <td>
                                    {{$cliente->correo}}
                                </td>
                                <td>
                                    {{$cliente->edad}}
                                    <a href="{{route('clientearriendo.edit', $cliente)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                        <i class="far fa-user-edit"></i>
                                </td>
                                
                                
                                
                                
                            </tr>
                            @endforeach
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
@endsection


        