@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">

    <div class="offset-3 col-12 col-md-6   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
        <div class="card-body" >
            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar arriendo</h3>
            {{-- <h5>{{$vehiculo->patente}}</h5> --}}
            <form action="{{route('arriendo.store',$vehiculo->patente)}}" method="post">
            
                @csrf
                <div class="form-group">
                    <label for="user" class="text-white text-center bg-ligth">valor arriendo</label>
                    <input type="text" id="user2" name='user2' class="form-control">
                    <small class="form-text text-muted">Indique el valor del arriendo.</small>
                </div>
                {{-- <div class="form-group">
                    <label for="user" class="text-white text-center bg-ligth">patente</label>
                    <input type="text" id="user" name='user' class="form-control">
                    <small class="form-text text-muted">Indique el correo del cliente.</small>
                </div> --}}
                <div class="form-group">
                    <label class="text-white text-center bg-ligth" for="user">Patente</label>
                    <select name="user" id="user" class="form-control">
                        
                        <option value="{{$vehiculo->patente}}">{{$vehiculo->patente}}</option>
                        
                        
                        
                    </select>
                    <small class="form-text text-muted">Indique la editorial.</small>
                    
                </div>
                <div class="form-group">
                    <label for="user"class="text-white text-center bg-ligth">estado</label>
                    <input type="text" id="tipo" name='tipo' class="form-control">
                    <small class="form-text text-muted">Indique la edad.</small>
                </div>
                <div class="form-group">
                    <label for="user"class="text-white text-center bg-ligth">cliente id</label>
                    <input type="text" id="cliente" name='cliente' class="form-control">
                    <small class="form-text text-muted">Indique la edad.</small>
                </div>
                <div class="form-group">
                    <label class="text-white text-center bg-ligth" for="user">cliente</label>
                    <select name="cliente" id="cliente" class="form-control">
                        @foreach ($clientes as $cliente)
                        <option value="{{$cliente->id}}">{{$cliente->nombre_cliente}}</option>
                        @endforeach
                        
                        
                        
                        
                    </select>
                    <small class="form-text text-muted">Indique la editorial.</small>
                    
                </div>
                <div class="form-group">
                    <label class="text-white text-center bg-ligth" for="fecha">Fecha inicio arriendo</label>
                    <input type="date" id="fecha1" name="fecha1" class="form-control">
                    <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                </div>
                <div class="form-group">
                    <label class="text-white text-center bg-ligth" for="fecha">Fecha termino arriendo</label>
                    <input type="date" id="fecha2" name="fecha2" class="form-control">
                    <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                </div>
                <div class="form-group">
                    <label class="text-white text-center bg-ligth" for="fecha">Fecha devolucion vehiculo</label>
                    <input type="date" id="fecha3" name="fecha3" class="form-control">
                    <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                </div>
               
                <div class="form-group">
                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                </div>
            </form>
        </div>
    
            
</div>