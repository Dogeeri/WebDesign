@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
    <div class="flex-container">
        <div class="row">
            <div class="col-12 col-md-6">
                <div class=" container " style="background-color: rgba(0, 0, 0, 0.781);">
                                
                    
                                
                        
                                    <div class="card-body" >

                                        <form action="{{route('arriendo.update',$arriendo->patente)}}" method="POST">
                                            
                                            @csrf
                                            @method('put')
                                            <div class="form-group">
                                                <label for="user" class="text-white text-center bg-ligth">valor arriendo</label>
                                                <input type="text" id="user2" name='user2' class="form-control">
                                                <small class="form-text text-muted">Indique el nombre del cliente.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user" class="text-white text-center bg-ligth">patente</label>
                                                <input type="text" id="user" name='user' class="form-control">
                                                <small class="form-text text-muted">Indique el correo del cliente.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user"class="text-white text-center bg-ligth">estado</label>
                                                <input type="text" id="tipo" name='tipo' class="form-control">
                                                <small class="form-text text-muted">Indique la edad.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user"class="text-white text-center bg-ligth">cliente id</label>
                                                <input type="text" id="cliente" name='cliente' class="form-control">
                                                <small class="form-text text-muted">Indique la edad.</small>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-white text-center bg-ligth" for="fecha">Fecha inicio arriendo</label>
                                                <input type="date" id="fecha1" name="fecha1" class="form-control">
                                                <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-white text-center bg-ligth" for="fecha">Fecha termino arriendo</label>
                                                <input type="date" id="fecha2" name="fecha2" class="form-control">
                                                <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-white text-center bg-ligth" for="fecha">Fecha devolucion vehiculo</label>
                                                <input type="date" id="fecha3" name="fecha3" class="form-control">
                                                <small class="form-text text-muted">Indique la fecha de publicacion.</small>
                                            </div>
                                            
                                            
            
                                            
            
                                        
                                            <div class="form-group">
                                                <button type="reset"  class="btn btn-warning">Cancelar</button>
                                                <button type="reset" class="btn btn-danger">Reiniciar</button>
                                                <button type="submit" class="btn btn-success">Enviar Datos</button>
                                            </div>
                                        </form>
                                    </div>
                            
                    
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class=" card " id= "rar" style="background-color: rgba(0, 0, 0, 0.781);">
                    <h4 class="text-white text-center">Editar arriendos</h4>
                    {{-- <img src="{{asset('imagenes/books37.jpg')}}" width="200" height="250" title="El codigo davinci" alt="Aquí esta la portada de el codigo davinci" class="card-img-top"/> --}}
                    <div class="card-body">
                        <div class="card-title">
                            <h4 class="text-white">{{$arriendo->nombre_arriendo}}</h4>
                            <ul class="list-group list-group-flush text-white">
                                <p>Nombre de la editorial: {{$arriendo->valor_arriendo}}</p>
                                <p>direccion de la editorial: {{$arriendo->patente}}</p>
                                <p>teléfono de la editorial: {{$arriendo->estado}}</p>
                                <p>Email de la editorial: {{$arriendo->cliente_id}}</p>
                                <p>pais de la editorial: {{$arriendo->fecha_inicio_arriendo}}</p>
                                <p>pais de la editorial: {{$arriendo->fecha_termino_arriendo}}</p>
                                <p>pais de la editorial: {{$arriendo->devolucion_vehiculo}}</p>
                                
                            </ul>
                        </div>
                        <div class=" row">
                            <div class="flex-container">
                                <div class="col-5">
                                    <p class="text-white ">Volver a editoriales      </p>
                                </div>
                                <div class="col-5">
                                   <a href="/editoriales" class="btn btn-success btn-lg active" title="comprar" role="button ">
                                       
                                       
                                       <i class="fas fa-arrow-alt-circle-left"></i>
                                       
                                   </a>
                                </div>
                                
           
                                
           
                                
                               
           
                            </div>
                        <p class="text-white" ></p>
        
                    </div>
                    
                </div>
        
        
            </div>
        </div>
    </div>
    
@endsection