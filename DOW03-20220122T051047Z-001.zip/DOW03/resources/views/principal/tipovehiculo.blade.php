@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar tipo de vehiculo</h3>
                            <form action="{{route('tipovehiculo.store')}}" method="post">
                            
                                @csrf
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Nombre tipo vehiculo</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique el nombre del tipo de vehiculo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Valor del arriendo</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique el valor del arriendo.</small>
                                </div>
                                {{-- <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="marca" name='marca' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="modelo" name='modelo' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                    <input type="text" id="color" name='color' class="form-control">
                                    <small class="form-text text-muted">Indique el genero.</small>
                                </div> --}}
                                
                                

                                

                            
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>Nombre_tipo</th>
                                <th>valor arriendo
                                </a></th> 
                                
                                
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            @foreach ($tipovehiculos as $tipovehiculo)
                            <tr>
                                <td>
                                    
                                    <form method="POST" action="{{route('tipovehiculo.destroy', $tipovehiculo->id)}}" >
                                        {{$tipovehiculo->nombre_tipo}}
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="{{route('tipovehiculo.edit', $tipovehiculo)}}" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                <td>
                                    {{$tipovehiculo->valor_de_arriendo}}
                                </td>
                                {{-- <td>
                                    {{$vehiculo->marca}}
                                </td>
                                
                                <td>
                                    {{$vehiculo->modelo}}
                                </td>
                                <td>
                                    {{$vehiculo->color}}
                                </td> --}}
                            </tr>
                            @endforeach
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
@endsection


        