@extends('master')
@section('css') 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="{{asset('css/inicio.css')}}">
@endsection
@section('contenido')
<body style="background-image: url({{asset('imagenes/imagen5.jpg')}}); background-repeat: no-repeat ;">
    <div class="flex-container">
        <div class="row">
            <div class="col-12 col-md-6">
                <div class=" container " style="background-color: rgba(0, 0, 0, 0.781);">
                                
                    
                                
                        
                                    <div class="card-body" >

                                        <form action="{{route('tipovehiculo.update',$tipovehiculo->id)}}" method="POST">
                                            
                                            @csrf
                                            @method('put')
                                            <div class="form-group">
                                                <label for="user" class="text-white text-center bg-ligth">Nombre tipo vehiculo</label>
                                                <input type="text" id="user2" name='user2' class="form-control">
                                                <small class="form-text text-muted">Indique el nombre del tipo de vehiculo.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user" class="text-white text-center bg-ligth">Valor del arriendo</label>
                                                <input type="text" id="user" name='user' class="form-control">
                                                <small class="form-text text-muted">Indique el valor del arriendo.</small>
                                            </div>
                                            {{-- <div class="form-group">
                                                <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                                <input type="text" id="marca" name='marca' class="form-control">
                                                <small class="form-text text-muted">Indique el genero.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                                <input type="text" id="modelo" name='modelo' class="form-control">
                                                <small class="form-text text-muted">Indique el genero.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="user"class="text-white text-center bg-ligth">Genero</label>
                                                <input type="text" id="color" name='color' class="form-control">
                                                <small class="form-text text-muted">Indique el genero.</small>
                                            </div> --}}
                                            
                                            
            
                                            
            
                                        
                                            <div class="form-group">
                                                <button type="reset"  class="btn btn-warning">Cancelar</button>
                                                <button type="reset" class="btn btn-danger">Reiniciar</button>
                                                <button type="submit" class="btn btn-success">Enviar Datos</button>
                                            </div>
                                        </form>
                                    </div>
                            
                    
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class=" card " id= "rar" style="background-color: rgba(0, 0, 0, 0.781);">
                    <h4 class="text-white text-center">Editar vehiculos</h4>
                    {{-- <img src="{{asset('imagenes/books37.jpg')}}" width="200" height="250" title="El codigo davinci" alt="Aquí esta la portada de el codigo davinci" class="card-img-top"/> --}}
                    <div class="card-body">
                        <div class="card-title">
                            <h4 class="text-white">{{$tipovehiculo->nombre_tipo}}</h4>
                            <ul class="list-group list-group-flush text-white">
                                <p>Nombre de la editorial: {{$tipovehiculo->nombre_tipo}}</p>
                                <p>direccion de la editorial: {{$tipovehiculo->valor_de_arriendo}}</p>
                                
                                
                            </ul>
                        </div>
                        <div class=" row">
                            <div class="flex-container">
                                {{-- <div class="col-5">
                                    <p class="text-white ">Volver a editoriales      </p>
                                </div> --}}
                                <div class="col-5">
                                   <a href="/editoriales" class="btn btn-success btn-lg active" title="comprar" role="button ">
                                       
                                       
                                       <i class="fas fa-arrow-alt-circle-left"></i>
                                       
                                   </a>
                                </div>
                                
           
                                
           
                                
                               
           
                            </div>
                        <p class="text-white" ></p>
        
                    </div>
                    
                </div>
        
        
            </div>
        </div>
    </div>
    
@endsection