<?php $__env->startSection('css'); ?> 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<body style="background-image: url(<?php echo e(asset('imagenes/imagen5.jpg')); ?>); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar vehiculo</h3>
                            <form action="<?php echo e(route('vehiculo.store')); ?>" method="post">
                            
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Patente</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique la patente.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Dueño del vehiculo</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique el nombre del dueño.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">tipo de vehiculo</label>
                                    <input type="text" id="tipo" name='tipo' class="form-control">
                                    <small class="form-text text-muted">Indique el tipo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Marca</label>
                                    <input type="text" id="marca" name='marca' class="form-control">
                                    <small class="form-text text-muted">Indique la marca.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">Modelo</label>
                                    <input type="text" id="modelo" name='modelo' class="form-control">
                                    <small class="form-text text-muted">Indique el modelo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">estado del vehiculo</label>
                                    <select name="estado" id="estado" class="form-control">
                                        
                                        <option value="disponible">disponible</option>
                                        <option value="arrendado">arrendado</option>
                                        <option value="mantenimiento">mantenimiento</option>
                                        <option value="de baja">de baja</option>
                                        
                                    </select>
                                    
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">color del vehiculo</label>
                                    <input type="text" id="color" name='color' class="form-control">
                                    <small class="form-text text-muted">Indique el color del vehiculo.</small>
                                </div>
                                
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>Patente</th>
                                <th>Dueño vehiculo
                                </a></th> 
                                <th>tipo
                                </a></th>
                                <th>marca </th>
                                <th>modelo </th>
                                <th>estado del vehiculo </th>
                                
                                
                                <th>acciones y color
                                </a></th></th>
                                
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    
                                    <form method="POST" action="<?php echo e(route('vehiculo.destroy', $vehiculo->patente)); ?>" >
                                        <?php echo e($vehiculo->patente); ?>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="<?php echo e(route('vehiculo.edit', $vehiculo)); ?>" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                <td>
                                    <?php echo e($vehiculo->dueño_vehiculo); ?>

                                </td>
                                <?php $__currentLoopData = $tipovehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipovehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <?php if($tipovehiculo->id==$vehiculo->tipo_vehiculos): ?> <td><?php echo e($tipovehiculo->nombre_tipo); ?> <a href="/autores" class="btn btn-success btn-lg active " title="autores" role="button ">
                                        
                                        <i class="far fa-book"></i> </td>  <?php endif; ?>
                            
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <td>
                                    <?php echo e($vehiculo->marca); ?>

                                </td>
                                <td>
                                    <?php echo e($vehiculo->modelo); ?>

                                </td>
                                
                                
                                <td>
                                    <?php echo e($vehiculo->estado_vehiculo); ?>

                                </td>
                                <td>
                                    <?php echo e($vehiculo->color); ?>

                                    
                                    <form method="POST" action="<?php echo e(route('vehiculo.destroy', $vehiculo->patente)); ?>" >
                                        
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="<?php echo e(route('vehiculo2.edit', $vehiculo)); ?>" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    

                                </td>
                                
                                    
                                
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edura\DOW03\DOW03\resources\views/principal/vehiculo.blade.php ENDPATH**/ ?>