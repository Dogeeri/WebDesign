
<?php $__env->startSection('css'); ?> 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<body style="background-image: url(<?php echo e(asset('imagenes/imagen5.jpg')); ?>); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar tipo de vehiculo</h3>
                            <form action="<?php echo e(route('tipovehiculo.store')); ?>" method="post">
                            
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Nombre tipo vehiculo</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique el nombre del tipo de vehiculo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">Valor del arriendo</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique el valor del arriendo.</small>
                                </div>
                                
                                
                                

                                

                            
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>Nombre_tipo</th>
                                <th>valor arriendo
                                </a></th> 
                                
                                
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__currentLoopData = $tipovehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipovehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    
                                    <form method="POST" action="<?php echo e(route('tipovehiculo.destroy', $tipovehiculo->id)); ?>" >
                                        <?php echo e($tipovehiculo->nombre_tipo); ?>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="<?php echo e(route('tipovehiculo.edit', $tipovehiculo)); ?>" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                <td>
                                    <?php echo e($tipovehiculo->valor_de_arriendo); ?>

                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edura\DOW03\DOW03\resources\views/principal/tipovehiculo.blade.php ENDPATH**/ ?>