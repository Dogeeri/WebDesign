
<?php $__env->startSection('css'); ?> 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<body style="background-image: url(<?php echo e(asset('imagenes/imagen5.jpg')); ?>); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                <?php $__currentLoopData = $arriendos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arriendo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cliente->id==$arriendo->cliente_id): ?>
                
                <div class="col-12 col-md-3">
                    <div class=" card " id= "rar" style="background-color: rgba(0, 0, 0, 0.781);">
                        <h4 class="text-white text-center">Editar vehiculos</h4>
                        
                        <div class="card-body">
                            <div class="card-title">
                                
                                <ul class="list-group list-group-flush text-white">
                                    
                                    
                                    
                                    
                                     <p>Nombre de la editorial: <?php echo e($cliente->nombre_cliente); ?></p>
                                    <p>direccion de la editorial: <?php echo e($cliente->correo); ?></p>
                                    <p>teléfono de la editorial: <?php echo e($cliente->edad); ?></p> <p>valor_arriendo:   <?php echo e($arriendo->valor_arriendo); ?></p>
                                    <p>patente:   <?php echo e($arriendo->patente); ?></p> <p>cliente_id:   <?php echo e($arriendo->cliente_id); ?></p> 
                                    
                                   
                                    
                                </ul>
                            </div>
                           
                        </div>
                        
                    </div>


                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
</body>

        
<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edura\DOW03\DOW03\resources\views/principal/arriendos.blade.php ENDPATH**/ ?>