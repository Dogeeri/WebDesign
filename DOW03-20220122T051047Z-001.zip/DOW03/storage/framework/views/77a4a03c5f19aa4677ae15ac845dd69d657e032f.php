
<?php $__env->startSection('css'); ?> 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<body style="background-image: url(<?php echo e(asset('imagenes/imagen5.jpg')); ?>); background-repeat: no-repeat ;">
        <div class="flex-container">
            <div class="row">
                
                <div class="col-12 col-md-3   " style="background-color: rgba(0, 0, 0, 0.781);">
                        
                    
                    
            
                        <div class="card-body" >
                            <h3 class="text-white text-center bg-ligth"  id="doit">Agregar arriendo</h3>
                            <form action="<?php echo e(route('arriendo.store')); ?>" method="post">
                            
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">valor arriendo</label>
                                    <input type="text" id="user2" name='user2' class="form-control">
                                    <small class="form-text text-muted">Indique el valor del arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user" class="text-white text-center bg-ligth">patente</label>
                                    <input type="text" id="user" name='user' class="form-control">
                                    <small class="form-text text-muted">Indique la patente.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">estado</label>
                                    <input type="text" id="tipo" name='tipo' class="form-control">
                                    <small class="form-text text-muted">Indique el estado.</small>
                                </div>
                                <div class="form-group">
                                    <label for="user"class="text-white text-center bg-ligth">cliente id</label>
                                    <input type="text" id="cliente" name='cliente' class="form-control">
                                    <small class="form-text text-muted">Indique el cliente id.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha inicio arriendo</label>
                                    <input type="date" id="fecha1" name="fecha1" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de inicion delm arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha termino arriendo</label>
                                    <input type="date" id="fecha2" name="fecha2" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de termino del arriendo.</small>
                                </div>
                                <div class="form-group">
                                    <label class="text-white text-center bg-ligth" for="fecha">Fecha devolucion vehiculo</label>
                                    <input type="date" id="fecha3" name="fecha3" class="form-control">
                                    <small class="form-text text-muted">Indique la fecha de devolucion del vehiculo.</small>
                                </div>
                                
                                
                                
                                
                                

                                

                            
                                <div class="form-group">
                                    <button type="reset"  class="btn btn-warning">Cancelar</button>
                                    <button type="reset" class="btn btn-danger">Reiniciar</button>
                                    <button type="submit" class="btn btn-success">Enviar Datos</button>
                                </div>
                            </form>
                        </div>
                    
                            
                </div>
                <div class="col-12 col-md-9   ">
                    
                        
                    <table class="table table-bordered table-striped table-hover table-sm table-success">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>valor arriendo
                                </a></th> 
                                <th>patente
                                </a></th>
                                <th>estado</th>
                                <th>id cliente </th>
                                <th>fecha inicio </th>
                                
                                
                                <th>fecha termino
                                </a></th>
                                <th>fecha devolucion</th>                       
                                
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__currentLoopData = $arriendos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arriendo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    
                                    
                                    <?php echo e($arriendo->id); ?>

                                    <form method="POST" action="<?php echo e(route('arriendo.destroy', $arriendo->id)); ?>" >
                                        
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-lg " data-toggle="tooltip" data-placement= "top" title="eliminar"><i class="far fa-user-slash"></i></button>
                                            <a href="<?php echo e(route('arriendo.edit', $arriendo)); ?>" class="btn btn-success btn-lg active " title="editar" role="button ">
                    
                                                <i class="far fa-user-edit"></i>
                                        
                                    </form>
                                    
                                    
                                </td>
                                
                                
                                <td>
                                    <?php echo e($arriendo->valor_arriendo); ?>

                                </td>
                                <td>
                                    <?php echo e($arriendo->patente); ?>

                                </td>
                                <td>
                                    <?php echo e($arriendo->estado); ?>

                                    
                                </td>
                                <td>
                                    <?php echo e($arriendo->cliente_id); ?>

                                </td>
                                <td>
                                    <?php echo e($arriendo->fecha_inicio_arriendo); ?>

                                </td>
                                <td>
                                    <?php echo e($arriendo->fecha_termino_arriendo); ?>

                                </td>
                                <td>
                                    <?php echo e($arriendo->devolucion_vehiculo); ?>

                                </td>
                                
                                
                                
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    
                        
                    </table>
            
    
            
                </div>
            </div>
        </div>
</body>

        
<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edura\DOW03\DOW03\resources\views/principal/arriendosindex.blade.php ENDPATH**/ ?>