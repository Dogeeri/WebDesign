<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

    <nav class="navbar navbar-expand-sm bg-info">
        <a class="navbar-brand text-white">Bienvenido a RentACar, <b><?php echo e(Auth::user()->nombre); ?></b> </a>
        

        <ul class="navbar-nav mr-auto">
            <a class="btn btn-dark mr-sm-3" href="/vehiculos">Vehiculos</a>
            <a class="btn btn-dark mr-sm-3" href="/arriendos">Arrendar Vehiculo</a>
            <a class="btn btn-dark mr-sm-3" href="/clientes">Clientes</a>
            <a class="btn btn-dark mr-sm-3" href="/tipovehiculos">Tipos de Vehiculos</a>
            <a class="btn btn-secondary mr-sm-3" href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a>
            <a class="btn btn-secondary mr-sm-3" href="<?php echo e(route('roles.index')); ?>">Roles</a>
            <a class="btn btn-warning mr-sm-3" href="<?php echo e(route('usuarios.logout')); ?>">Cerrar Sesión</a>
        </ul>

        
        <span class="navbar-text mr-sm-3">
            <small>Ultimo inicio de sesion: <?php echo e(date('d-m-Y',strtotime(Auth::user()->ultimo_login))); ?> a las <?php echo e(date('H:i:s',strtotime(Auth::user()->ultimo_login))); ?>  </small>
        </span>

    </nav>
     <?php echo $__env->yieldContent('contenido'); ?>
        


        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\edura\DOW03\DOW03\resources\views/master.blade.php ENDPATH**/ ?>