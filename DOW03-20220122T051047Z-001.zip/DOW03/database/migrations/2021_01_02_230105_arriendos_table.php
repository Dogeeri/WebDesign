<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ArriendosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('arriendos', function (Blueprint $table) {
            $table->id();
            
            $table->string('valor_arriendo',70);
            $table->string('patente',6);
            $table->string('estado',10);
            $table->unsignedBigInteger('cliente_id');
            $table->date('fecha_inicio_arriendo');
            $table->date('fecha_termino_arriendo');
            $table->date('devolucion_vehiculo');
            
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('patente')->references('patente')->on('vehiculos');
            $table->foreign('cliente_id')->references('id')->on('clientes');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('arriendos');
    }
}
