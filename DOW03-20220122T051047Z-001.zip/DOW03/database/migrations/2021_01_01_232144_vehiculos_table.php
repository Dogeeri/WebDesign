<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class VehiculosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vehiculos', function (Blueprint $table) {
            // $table->id();
            $table->string('patente',6)->primary();
            $table->string('dueño_vehiculo',70);
            $table->unsignedBigInteger ('tipo_vehiculos');
            $table->string('marca',70);
            $table->string('modelo',70);
            $table->string('color',70);
            $table->string('estado_vehiculo',70);
            $table->timestamps();
            
            $table->softDeletes();
            $table->foreign('tipo_vehiculos')->references('id')->on('tipos_vehiculos');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vehiculos');
    }
}
